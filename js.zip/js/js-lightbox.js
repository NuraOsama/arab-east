(function ($) {


    $('.gallery a').simpleLightbox({
        
        animationSpeed:200,
        fadeSpeed: 200,
    
    
    });
        

})(jQuery);    