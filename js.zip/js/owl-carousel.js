(function ($) {

  let owl = $('.owl-slider');
  owl.owlCarousel({
  
      items: 1,
      nav: true,
      dots:true,
      loop:false,
      margin:0,
      autoplay:true,
      smartSpeed:5000,
      autoplayTimeout:3500,
      autoplayHoverPause:true,
      animateIn: 'fadeInLeft',
      animateOut: 'fadeOutLeft'
  
  });

  // first item animation
  
/*  $(".ite-1 .main-title h2").attr({
  
      'data-animation-in':'fadeInLeft',
      'data-animation-out':'animate-out fadeOutLeft',
  })
  // second item animation
  
  $(".ite-2 .main-title h2").attr({
  
      'data-animation-in':'slideInUp',
      'data-animation-out':'animate-out slideOutUp',
  })
  // third item animation
  
  $(".ite-3 .main-title h2").attr({
  
      'data-animation-in':'fadeInLeft',
      'data-animation-out':'animate-out fadeOutLeft',
  })

  function setAnimation ( _elem, _InOut ) {
    // Store all animationend event name in a string.
    // cf animate.css documentation
    let animationEndEvent = 'webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend';

    _elem.each ( function () {
      let $elem = $(this);
      let $animationType = 'animated ' + $elem.data( 'animation-' + _InOut );

      $elem.addClass($animationType).one(animationEndEvent, function () {
        $elem.removeClass($animationType); // remove animate.css Class at the end of the animations
      });
    });
  }

// Fired before current slide change
  owl.on('change.owl.carousel', function(event) {
      let $currentItem = $('.owl-item', owl).eq(event.item.index);
      let $elemsToanim = $currentItem.find("[data-animation-out]");
      setAnimation ($elemsToanim, 'out');
  });

// Fired after current slide has been changed
  let round = 0;
  owl.on('changed.owl.carousel', function(event) {

      let $currentItem = $('.owl-item', owl).eq(event.item.index);
      let $elemsToanim = $currentItem.find("[data-animation-in]");
    
      setAnimation ($elemsToanim, 'in');
  })
  
  owl.on('translated.owl.carousel', function(event) {
  //  console.log (event.item.index, event.page.count);
    
      if (event.item.index == (event.page.count - 1))  {
        if (round < 1) {
          round++
          console.log (round);
        } else {
          //owl.trigger('stop.owl.autoplay');
          let owlData = owl.data('owl.carousel');
         // owlData.settings.autoplay = false; //don't know if both are necessary
         // owlData.options.autoplay = false;
          owl.trigger('refresh.owl.carousel');
        }
      }
      
  });*/


// projects

let owlprojects = $('.owl-projects');
owlprojects.owlCarousel({

  items:3,
  loop:true,
  nav:true,
  dots:false,
  margin:15,
  autoplay:true,
  smartSpeed:3000,
  autoplaySpeed: 3000,
  autoplayTimeout:3000,
  autoplayHoverPause: true,
  responsiveClass:true,
  responsive:{
   1440:{
     items:3,

   },

   1024:{

     items:3,

   },

   991:{
     items:2,
 
   },

   768 : {

     items:1,
      
   },

   766 : {

    items:1,
     
  },


  575 : {

     items:1,
      
   },

   500 : {

     items:1,
      
   },

  
  425: {

     items:1,
              
   },

   375: {

     items:1,
              
   },

   320: {

       items:1,
     
   },
   300: {

    items:1,
  
},
  200: {

  items:1,

  }

 }
 
});

//owl testimonials

let owltestimonials = $('.owl-testimonials');
owltestimonials.owlCarousel({

 items:2,
 loop:true,
 nav:false,
 dots:true,
 margin:15,
 autoplay:true,
 smartSpeed:3000,
 autoplaySpeed: 3000,
 autoplayTimeout:3000,
 autoplayHoverPause: true,
 responsiveClass:true,
 responsive:{
  1440:{
    items:2,

  },

  1024:{

    items:2,

  },

  991:{
    items:1,

  },

  768 : {

    items:1,
     
  },

  766 : {

   items:1,
    
 },


 575 : {

    items:1,
     
  },



  500 : {

    items:1,
     
  },
   
   
 425: {

    items:1,
             
  },

  375: {

    items:1,
             
  },

  320: {

      items:1,
    
  },
  300: {

   items:1,
 
},
 200: {

 items:1,

 }
}
 
});


 //owl clients

 let owlclients = $('.owl-clients');
 owlclients.owlCarousel({

  items:6,
  loop:true,
  nav:false,
  dots:false,
  margin:30,
  autoplay:true,
  smartSpeed:3000,
  autoplaySpeed: 3000,
  autoplayTimeout:3000,
  autoplayHoverPause: true,
  responsiveClass:true,
  responsive:{
   1440:{
     items:6,

   },

   1024:{

     items:6,

   },

   991:{
     items:3,
 
   },

   768 : {

     items:2,
      
   },

   766 : {

    items:2,
     
  },


  575 : {

     items:1,
      
   },



   500 : {

     items:1,
      
   },
    
    
  425: {

     items:1,
              
   },

   375: {

     items:1,
              
   },

   320: {

       items:1,
     
   },
   300: {

    items:1,
  
},
  200: {

  items:1,

  }
 }
  
});


// owl nav
$( ".owl-carousel  .owl-prev").html('<span><i class="fas fa-angle-left"></i></span>');
$( ".owl-carousel   .owl-next").html('<span><i class="fas fa-angle-right"></i></span>');

// owl nav slider
$( ".owl-slider  .owl-prev").html('<span><img src="images/arrow-left-icon.png"/></span>');
$( ".owl-slider  .owl-next").html('<span><img src="images/arrow-right-icon.png"/></span>');

// owl nav projects
$( ".owl-projects  .owl-prev").html('<span><img src="images/project-arrow-left-icon.png"/></span>');
$( ".owl-projects  .owl-next").html('<span><img src="images/project-arrow-right-icon.png"/></span>');

})(jQuery);    