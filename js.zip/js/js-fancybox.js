(function ($) {


   // fancy-box images

   $(".fancybox-thumb")
   .fancybox({
       padding    : 0,
       margin     : 5,
       openEffect	: 'elastic',
       closeEffect	: 'elastic',
       autoCenter : true,
       autoPlay:true,
       loop:true,
       afterLoad  : function () {
         
           $.extend(this, {
               aspectRatio : false,
               type    : 'html',
               width   : 700,
               height  : 500,
               content : '<div class="fancybox-image" style="background-image:url(' + this.href + '); background-size:cover; background-position:center;background-repeat:no-repeat;height:100%;width:100%;" /></div>'
           });
       }
     
   });

})(jQuery);    